# Trummer baseline

Paper-style adaptive block join using one main model. The complete question is
placed in the semantic join prompt; no SUQL-style structured pruning or cascade
is used.

Responses use a simple line-oriented ID/decision protocol with tolerant parsing,
so execution does not depend on provider-specific structured-output support.

Use the shared benchmark flag `--methods trummer_baseline`.
